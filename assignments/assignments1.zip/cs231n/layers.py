from builtins import range
import numpy as np

def affine_forward(x, w, b):
    N = x.shape[0]
    x_reshaped = x.reshape(N, -1)
    out = x_reshaped.dot(w) + b
    cache = (x, w, b)
    return out, cache

def affine_backward(dout, cache):
    x, w, b = cache
    N = x.shape[0]
    x_reshaped = x.reshape(N, -1)
    dx = dout.dot(w.T).reshape(x.shape)
    dw = x_reshaped.T.dot(dout)
    db = np.sum(dout, axis=0)
    return dx, dw, db

def relu_forward(x):
    out = np.maximum(0, x)
    cache = x
    return out, cache

def relu_backward(dout, cache):
    x = cache
    dx = dout * (x > 0)
    return dx

def svm_loss(x, y):
    N = x.shape[0]
    correct_class_scores = x[np.arange(N), y][:, np.newaxis]
    margins = np.maximum(0, x - correct_class_scores + 1)
    margins[np.arange(N), y] = 0
    loss = np.sum(margins) / N

    num_pos = (margins > 0).astype(float)
    num_pos[np.arange(N), y] = -np.sum(num_pos, axis=1)
    dx = num_pos / N
    return loss, dx

def softmax_loss(x, y):
    shifted_logits = x - np.max(x, axis=1, keepdims=True)
    Z = np.sum(np.exp(shifted_logits), axis=1, keepdims=True)
    log_probs = shifted_logits - np.log(Z)
    probs = np.exp(log_probs)
    N = x.shape[0]
    loss = -np.sum(log_probs[np.arange(N), y]) / N
    dx = probs.copy()
    dx[np.arange(N), y] -= 1
    dx /= N
    return loss, dx