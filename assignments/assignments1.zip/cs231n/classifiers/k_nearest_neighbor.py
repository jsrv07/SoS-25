import numpy as np

class KNearestNeighbor(object):
    """
    k-Nearest Neighbor classifier using L2 distance.
    Train data is just stored, and prediction is done by computing
    distances between test and train points.
    """
    def __init__(self):
        # no parameters to initialize
        pass

    def train(self, X, y):
        """
        Train the classifier. For kNN this simply memorizes the training data.

        Inputs:
        - X: A numpy array of shape (num_train, D) containing the training data.
        - y: A numpy array of shape (num_train,) containing the training labels.
        """
        self.X_train = X
        self.y_train = y

    def predict(self, X, k=1, num_loops=0):
        """
        Predict labels for test data using this classifier.

        Inputs:
        - X: A numpy array of shape (num_test, D) containing test data.
        - k: The number of nearest neighbors that vote.
        - num_loops: Determines which implementation to use to compute distances.
          0: no loops, 1: one loop, 2: two loops.

        Returns:
        - y_pred: Predicted labels for the test data, shape (num_test,).
        """
        # Compute distances between test points and training points
        if num_loops == 2:
            dists = self.compute_distances_two_loops(X)
        elif num_loops == 1:
            dists = self.compute_distances_one_loop(X)
        elif num_loops == 0:
            dists = self.compute_distances_no_loops(X)
        else:
            raise ValueError("Invalid value %d for num_loops" % num_loops)

        # Predict labels based on computed distances
        return self.predict_labels(dists, k=k)

    def compute_distances_two_loops(self, X):
        """
        Compute the distance matrix using a nested loop over both test and train sets.

        Input:
        - X: A numpy array of shape (num_test, D) containing test data.

        Returns:
        - dists: A numpy array of shape (num_test, num_train) where dists[i, j]
          is the Euclidean distance between the i-th test point and the j-th training point.
        """
        num_test = X.shape[0]
        num_train = self.X_train.shape[0]
        dists = np.zeros((num_test, num_train))
        for i in range(num_test):
            for j in range(num_train):
                # L2 distance: sqrt(sum((x - y)^2))
                dists[i, j] = np.linalg.norm(X[i] - self.X_train[j])
        return dists

    def compute_distances_one_loop(self, X):
        """
        Compute the distance matrix using one loop over the test data.

        Input / Output: Same as compute_distances_two_loops
        """
        num_test = X.shape[0]
        num_train = self.X_train.shape[0]
        dists = np.zeros((num_test, num_train))
        for i in range(num_test):
            # vectorized computation over training set
            diff = self.X_train - X[i]  # shape (num_train, D)
            dists[i, :] = np.sqrt(np.sum(diff**2, axis=1))
        return dists

    def compute_distances_no_loops(self, X):
        """
        Compute the distance matrix without any explicit loops.

        This uses the identity:
        (x - y)^2 = x^2 - 2xy + y^2

        Inputs / Output: Same as compute_distances_two_loops
        """
        # shape (num_test, 1)
        X_sq = np.sum(X**2, axis=1, keepdims=True)
        # shape (num_train,)
        train_sq = np.sum(self.X_train**2, axis=1)
        # inner product shape (num_test, num_train)
        cross = X.dot(self.X_train.T)
        # broadcast to compute all distances
        dists = np.sqrt(X_sq - 2 * cross + train_sq)
        return dists

    def predict_labels(self, dists, k=1):
        """
        Given a matrix of distances, predict a label for each test point.

        Inputs:
        - dists: A numpy array of shape (num_test, num_train).
        - k: The number of nearest neighbors to use for voting.

        Returns:
        - y_pred: A numpy array of shape (num_test,) containing predicted labels.
        """
        num_test = dists.shape[0]
        y_pred = np.zeros(num_test, dtype=self.y_train.dtype)
        for i in range(num_test):
            # find the k nearest training samples
            closest_idxs = np.argsort(dists[i])[:k]
            closest_y = self.y_train[closest_idxs]
            # count occurrences of each label
            labels, counts = np.unique(closest_y, return_counts=True)
            # choose the label with the highest count (break ties by smallest label)
            y_pred[i] = labels[np.argmax(counts)]
        return y_pred
