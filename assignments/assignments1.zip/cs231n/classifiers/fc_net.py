from builtins import range
from builtins import object
import os
import numpy as np

from ..layers import *
from ..layer_utils import *


class TwoLayerNet(object):
    """
    A two-layer fully-connected neural network with ReLU nonlinearity and
    softmax loss that uses a modular layer design. The architecture is:
    affine - relu - affine - softmax
    """

    def __init__(self, input_dim=3*32*32, hidden_dim=100, num_classes=10,
                 weight_scale=1e-3, reg=0.0):
        self.params = {}
        self.reg = reg

        # Initialize weights and biases
        self.params['W1'] = weight_scale * np.random.randn(input_dim, hidden_dim)
        self.params['b1'] = np.zeros(hidden_dim)
        self.params['W2'] = weight_scale * np.random.randn(hidden_dim, num_classes)
        self.params['b2'] = np.zeros(num_classes)

    def loss(self, X, y=None):
        W1, b1 = self.params['W1'], self.params['b1']
        W2, b2 = self.params['W2'], self.params['b2']

        # Forward pass
        a1, fc1_cache = affine_forward(X, W1, b1)
        h1, relu_cache = relu_forward(a1)
        scores, fc2_cache = affine_forward(h1, W2, b2)

        if y is None:
            return scores  # test mode

        # Compute loss
        loss, dscores = softmax_loss(scores, y)
        loss += 0.5 * self.reg * (np.sum(W1 * W1) + np.sum(W2 * W2))

        # Backward pass
        grads = {}
        dh1, grads['W2'], grads['b2'] = affine_backward(dscores, fc2_cache)
        da1 = relu_backward(dh1, relu_cache)
        dx, grads['W1'], grads['b1'] = affine_backward(da1, fc1_cache)

        grads['W1'] += self.reg * W1
        grads['W2'] += self.reg * W2

        return loss, grads

    def save(self, fname):
        fpath = os.path.join(os.path.dirname(__file__), "../saved/", fname)
        params = self.params
        np.save(fpath, params)
        print(fname, "saved.")

    def load(self, fname):
        fpath = os.path.join(os.path.dirname(__file__), "../saved/", fname)
        if not os.path.exists(fpath):
            print(fname, "not available.")
            return False
        else:
            params = np.load(fpath, allow_pickle=True).item()
            self.params = params
            print(fname, "loaded.")
            return True
