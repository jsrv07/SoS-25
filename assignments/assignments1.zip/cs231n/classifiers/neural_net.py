import numpy as np

class TwoLayerNet(object):
    def __init__(self, input_size, hidden_size, output_size, std=1e-4):
        self.params = {}
        self.params['W1'] = std * np.random.randn(input_size, hidden_size)
        self.params['b1'] = np.zeros(hidden_size)
        self.params['W2'] = std * np.random.randn(hidden_size, output_size)
        self.params['b2'] = np.zeros(output_size)

    def loss(self, X, y=None, reg=0.0):
        W1, b1 = self.params['W1'], self.params['b1']
        W2, b2 = self.params['W2'], self.params['b2']
        N, D = X.shape

        # Forward pass
        hidden = np.maximum(0, X.dot(W1) + b1)  # ReLU
        scores = hidden.dot(W2) + b2

        if y is None:
            return scores

        # Compute the softmax loss
        scores -= np.max(scores, axis=1, keepdims=True)
        exp_scores = np.exp(scores)
        probs = exp_scores / np.sum(exp_scores, axis=1, keepdims=True)
        correct_log_probs = -np.log(probs[np.arange(N), y])
        data_loss = np.mean(correct_log_probs)
        reg_loss = 0.5 * reg * (np.sum(W1 * W1) + np.sum(W2 * W2))
        loss = data_loss + reg_loss

        # Backward pass
        grads = {}
        dscores = probs
        dscores[np.arange(N), y] -= 1
        dscores /= N

        grads['W2'] = hidden.T.dot(dscores) + reg * W2
        grads['b2'] = np.sum(dscores, axis=0)

        dhidden = dscores.dot(W2.T)
        dhidden[hidden <= 0] = 0

        grads['W1'] = X.T.dot(dhidden) + reg * W1
        grads['b1'] = np.sum(dhidden, axis=0)

        return loss, grads

    def train(self, X, y, X_val, y_val,
              learning_rate=1e-3, learning_rate_decay=0.95,
              reg=1e-5, num_iters=100,
              batch_size=200, verbose=False):
        num_train = X.shape[0]
        iterations_per_epoch = max(num_train // batch_size, 1)

        loss_history = []
        train_acc_history = []
        val_acc_history = []

        for it in range(num_iters):
            indices = np.random.choice(num_train, batch_size)
            X_batch = X[indices]
            y_batch = y[indices]

            loss, grads = self.loss(X_batch, y_batch, reg)
            loss_history.append(loss)

            # Update parameters
            for param in self.params:
                self.params[param] -= learning_rate * grads[param]

            if verbose and it % 100 == 0:
                print(f'iteration {it}/{num_iters}: loss {loss:.4f}')

            # Check accuracy and decay learning rate
            if it % iterations_per_epoch == 0:
                train_acc = (self.predict(X_batch) == y_batch).mean()
                val_acc = (self.predict(X_val) == y_val).mean()
                train_acc_history.append(train_acc)
                val_acc_history.append(val_acc)
                learning_rate *= learning_rate_decay

        return {
            'loss_history': loss_history,
            'train_acc_history': train_acc_history,
            'val_acc_history': val_acc_history,
        }

    def predict(self, X):
        hidden = np.maximum(0, X.dot(self.params['W1']) + self.params['b1'])
        scores = hidden.dot(self.params['W2']) + self.params['b2']
        y_pred = np.argmax(scores, axis=1)
        return y_pred
