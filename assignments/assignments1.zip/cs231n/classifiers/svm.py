import numpy as np

def svm_loss_vectorized(W, X, y, reg):
    num_train = X.shape[0]
    scores = X.dot(W)
    correct_class_scores = scores[np.arange(num_train), y].reshape(-1, 1)
    margins = np.maximum(0, scores - correct_class_scores + 1)
    margins[np.arange(num_train), y] = 0

    loss = np.sum(margins) / num_train
    loss += 0.5 * reg * np.sum(W * W)

    mask = (margins > 0).astype(float)
    mask[np.arange(num_train), y] -= np.sum(mask, axis=1)
    dW = X.T.dot(mask) / num_train
    dW += reg * W

    return loss, dW
