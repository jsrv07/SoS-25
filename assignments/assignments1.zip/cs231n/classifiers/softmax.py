import numpy as np
from random import shuffle

def softmax_loss_naive(W, X, y, reg):
    """
    Softmax loss function, naive implementation (with loops)

    Inputs:
    - W: weights (D, C)
    - X: input data (N, D)
    - y: labels (N,)
    - reg: regularization strength

    Returns a tuple of:
    - loss: single float
    - dW: gradient with respect to weights W (D, C)
    """
    loss = 0.0
    dW = np.zeros_like(W)
    num_classes = W.shape[1]
    num_train = X.shape[0]

    for i in range(num_train):
        scores = X[i].dot(W)
        scores -= np.max(scores)  # for numeric stability
        exp_scores = np.exp(scores)
        probs = exp_scores / np.sum(exp_scores)
        loss += -np.log(probs[y[i]])

        for j in range(num_classes):
            dW[:, j] += (probs[j] - (j == y[i])) * X[i]

    loss /= num_train
    dW /= num_train

    loss += 0.5 * reg * np.sum(W * W)
    dW += reg * W

    return loss, dW


def softmax_loss_vectorized(W, X, y, reg):
    """
    Softmax loss function, vectorized version.

    Inputs and outputs are the same as softmax_loss_naive.
    """
    num_train = X.shape[0]

    # Compute the scores
    scores = X.dot(W)
    scores -= np.max(scores, axis=1, keepdims=True)  # stability fix
    exp_scores = np.exp(scores)
    probs = exp_scores / np.sum(exp_scores, axis=1, keepdims=True)
    correct_class_probs = probs[np.arange(num_train), y]

    # Compute the loss
    loss = -np.sum(np.log(correct_class_probs)) / num_train
    loss += 0.5 * reg * np.sum(W * W)

    # Compute the gradient
    probs[np.arange(num_train), y] -= 1  # dL/dscores
    dW = X.T.dot(probs) / num_train
    dW += reg * W

    return loss, dW
