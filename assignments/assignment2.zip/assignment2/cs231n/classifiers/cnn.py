from builtins import object
import numpy as np

from ..layers import *
from ..fast_layers import *
from ..layer_utils import *


class ThreeLayerConvNet(object):
    """
    A three-layer convolutional network with the following architecture:

    conv - relu - 2x2 max pool - affine - relu - affine - softmax

    The network operates on minibatches of data that have shape (N, C, H, W)
    consisting of N images, each with height H and width W and with C input
    channels.
    """

    def __init__(
        self,
        input_dim=(3, 32, 32),
        num_filters=32,
        filter_size=7,
        hidden_dim=100,
        num_classes=10,
        weight_scale=1e-3,
        reg=0.0,
        dtype=np.float32,
    ):
        """
        Initialize a new network.

        Inputs:
        - input_dim: Tuple (C, H, W) giving size of input data
        - num_filters: Number of filters to use in the convolutional layer
        - filter_size: Width/height of filters to use in the convolutional layer
        - hidden_dim: Number of units to use in the fully-connected hidden layer
        - num_classes: Number of scores to produce from the final affine layer.
        - weight_scale: Scalar giving standard deviation for random initialization
          of weights.
        - reg: Scalar giving L2 regularization strength
        - dtype: numpy datatype to use for computation.
        """
        self.params = {}
        self.reg = reg
        self.dtype = dtype

        # Unpack input dimensions
        C, H, W = input_dim
        # Initialize weights and biases for the convolutional layer
        self.params['W1'] = weight_scale * np.random.randn(
            num_filters, C, filter_size, filter_size)
        self.params['b1'] = np.zeros(num_filters)

        # After conv-relu-pool, spatial dims are halved by 2x2 pool with stride 2
        pool_height, pool_width, pool_stride = 2, 2, 2
        H_pool = (H - pool_height) // pool_stride + 1
        W_pool = (W - pool_width) // pool_stride + 1
        # Flatten dimension for affine layer
        D = num_filters * H_pool * W_pool

        # Initialize weights and biases for the hidden affine layer
        self.params['W2'] = weight_scale * np.random.randn(D, hidden_dim)
        self.params['b2'] = np.zeros(hidden_dim)

        # Initialize weights and biases for the output affine layer
        self.params['W3'] = weight_scale * np.random.randn(hidden_dim, num_classes)
        self.params['b3'] = np.zeros(num_classes)

        # Convert parameters to correct dtype
        for k, v in self.params.items():
            self.params[k] = v.astype(dtype)

    def loss(self, X, y=None):
        """
        Evaluate loss and gradient for the three-layer convolutional network.

        Input / output: Same API as TwoLayerNet in fc_net.py.
        """
        W1, b1 = self.params["W1"], self.params["b1"]
        W2, b2 = self.params["W2"], self.params["b2"]
        W3, b3 = self.params["W3"], self.params["b3"]

        # pass conv_param to the forward pass for the convolutional layer
        filter_size = W1.shape[2]
        conv_param = {'stride': 1, 'pad': (filter_size - 1) // 2}

        # pass pool_param to the forward pass for the max-pooling layer
        pool_param = {'pool_height': 2, 'pool_width': 2, 'stride': 2}

        scores = None
        # Forward pass: conv - relu - pool
        out1, cache1 = conv_relu_pool_forward(X, W1, b1, conv_param, pool_param)
        # Forward pass: affine - relu
        out2, cache2 = affine_relu_forward(out1, W2, b2)
        # Forward pass: affine
        scores, cache3 = affine_forward(out2, W3, b3)

        # If test mode return early
        if y is None:
            return scores

        loss, grads = 0, {}
        # Compute softmax loss
        data_loss, dscores = softmax_loss(scores, y)
        # Add L2 regularization to loss
        reg_loss = 0.5 * self.reg * (
            np.sum(W1 * W1) + np.sum(W2 * W2) + np.sum(W3 * W3)
        )
        loss = data_loss + reg_loss

        # Backward pass: affine backward
        dout2, dW3, db3 = affine_backward(dscores, cache3)
        # Backward pass: affine-relu backward
        dout1, dW2, db2 = affine_relu_backward(dout2, cache2)
        # Backward pass: conv-relu-pool backward
        dX, dW1, db1 = conv_relu_pool_backward(dout1, cache1)

        # Add regularization to gradients
        dW3 += self.reg * W3
        dW2 += self.reg * W2
        dW1 += self.reg * W1

        # Store gradients
        grads['W1'], grads['b1'] = dW1, db1
        grads['W2'], grads['b2'] = dW2, db2
        grads['W3'], grads['b3'] = dW3, db3

        return loss, grads
