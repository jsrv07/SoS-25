import numpy as np


def affine_forward(x, w, b):
    """Computes the forward pass for an affine (fully connected) layer."""
    N = x.shape[0]
    x_row = x.reshape(N, -1)  # (N, D)
    out = x_row.dot(w) + b    # (N, M)
    cache = (x, w, b)
    return out, cache


def affine_backward(dout, cache):
    """Computes the backward pass for an affine layer."""
    x, w, b = cache
    N = x.shape[0]
    x_row = x.reshape(N, -1)  # (N, D)
    dw = x_row.T.dot(dout)    # (D, M)
    db = np.sum(dout, axis=0) # (M,)
    dx_row = dout.dot(w.T)    # (N, D)
    dx = dx_row.reshape(x.shape)
    return dx, dw, db


def relu_forward(x):
    """Forward pass for ReLU."""
    out = np.maximum(0, x)
    cache = x
    return out, cache


def relu_backward(dout, cache):
    """Backward pass for ReLU."""
    x = cache
    dx = dout * (x > 0)
    return dx


def softmax_loss(x, y):
    """Loss and gradient for softmax classification."""
    shifted_logits = x - np.max(x, axis=1, keepdims=True)
    Z = np.sum(np.exp(shifted_logits), axis=1, keepdims=True)
    log_probs = shifted_logits - np.log(Z)
    probs = np.exp(log_probs)
    N = x.shape[0]
    loss = -np.sum(log_probs[np.arange(N), y]) / N
    dx = probs.copy()
    dx[np.arange(N), y] -= 1
    dx /= N
    return loss, dx


def batchnorm_forward(x, gamma, beta, bn_param):
    mode = bn_param['mode']
    eps = bn_param.get('eps', 1e-5)
    momentum = bn_param.get('momentum', 0.9)
    N, D = x.shape
    running_mean = bn_param.get('running_mean', np.zeros(D, dtype=x.dtype))
    running_var = bn_param.get('running_var', np.zeros(D, dtype=x.dtype))

    if mode == 'train':
        mu = np.mean(x, axis=0)
        var = np.var(x, axis=0)
        std = np.sqrt(var + eps)
        x_norm = (x - mu) / std
        out = gamma * x_norm + beta
        cache = (x, x_norm, mu, var, std, gamma, beta, eps)
        running_mean = momentum * running_mean + (1 - momentum) * mu
        running_var  = momentum * running_var  + (1 - momentum) * var
    elif mode == 'test':
        x_norm = (x - running_mean) / np.sqrt(running_var + eps)
        out = gamma * x_norm + beta
        cache = None
    else:
        raise ValueError('Invalid forward batchnorm mode')

    bn_param['running_mean'] = running_mean
    bn_param['running_var'] = running_var
    return out, cache


def batchnorm_backward(dout, cache):
    x, x_norm, mu, var, std, gamma, beta, eps = cache
    N, D = x.shape

    dbeta = np.sum(dout, axis=0)
    dgamma = np.sum(dout * x_norm, axis=0)
    dx_norm = dout * gamma

    dvar = np.sum(dx_norm * (x - mu) * -0.5 * (var + eps)**(-1.5), axis=0)
    dmu = np.sum(dx_norm * -1/std, axis=0) + dvar * np.mean(-2*(x-mu), axis=0)

    dx = dx_norm / std + dvar * 2*(x-mu)/N + dmu / N
    return dx, dgamma, dbeta


def batchnorm_backward_alt(dout, cache):
    x, x_norm, mu, var, std, gamma, beta, eps = cache
    N, D = x.shape

    dbeta = np.sum(dout, axis=0)
    dgamma = np.sum(dout * x_norm, axis=0)

    dx_norm = dout * gamma
    dx = (1. / N) * (1. / std) * (N * dx_norm - np.sum(dx_norm, axis=0)
         - x_norm * np.sum(dx_norm * x_norm, axis=0))
    return dx, dgamma, dbeta


def layernorm_forward(x, gamma, beta, ln_param):
    eps = ln_param.get('eps', 1e-5)
    mu = np.mean(x, axis=1, keepdims=True)
    var = np.var(x, axis=1, keepdims=True)
    std = np.sqrt(var + eps)
    x_norm = (x - mu) / std
    out = gamma * x_norm + beta
    cache = (x, x_norm, mu, var, std, gamma, beta, eps)
    return out, cache


def layernorm_backward(dout, cache):
    x, x_norm, mu, var, std, gamma, beta, eps = cache
    N, D = x.shape

    dbeta = np.sum(dout, axis=0)
    dgamma = np.sum(dout * x_norm, axis=0)
    dx_norm = dout * gamma

    dvar = np.sum(dx_norm * (x - mu) * -0.5 * (var + eps)**(-1.5), axis=1, keepdims=True)
    dmu = np.sum(dx_norm * -1/std, axis=1, keepdims=True) + dvar * np.mean(-2*(x-mu), axis=1, keepdims=True)

    dx = dx_norm / std + dvar * 2*(x-mu)/D + dmu / D
    return dx, dgamma, dbeta


def dropout_forward(x, dropout_param):
    p, mode = dropout_param['p'], dropout_param['mode']
    mask = None
    if 'seed' in dropout_param:
        np.random.seed(dropout_param['seed'])

    if mode == 'train':
        mask = (np.random.rand(*x.shape) < p) / p
        out = x * mask
    elif mode == 'test':
        out = x
    else:
        raise ValueError('Invalid dropout mode')

    cache = (dropout_param, mask)
    out = out.astype(x.dtype, copy=False)
    return out, cache


def dropout_backward(dout, cache):
    dropout_param, mask = cache
    mode = dropout_param['mode']
    if mode == 'train':
        dx = dout * mask
    elif mode == 'test':
        dx = dout
    else:
        raise ValueError('Invalid dropout mode')
    return dx


def conv_forward_naive(x, w, b, conv_param):
    N, C, H, W = x.shape
    F, _, HH, WW = w.shape
    stride, pad = conv_param['stride'], conv_param['pad']
    H_out = 1 + (H + 2*pad - HH) // stride
    W_out = 1 + (W + 2*pad - WW) // stride

    x_pad = np.pad(x, ((0,), (0,), (pad,), (pad,)), mode='constant')
    out = np.zeros((N, F, H_out, W_out))

    for i in range(H_out):
        for j in range(W_out):
            x_slice = x_pad[:, :, i*stride:i*stride+HH, j*stride:j*stride+WW]
            for f in range(F):
                out[:, f, i, j] = np.sum(x_slice * w[f, :, :, :], axis=(1,2,3)) + b[f]

    cache = (x, w, b, conv_param, x_pad)
    return out, cache


def conv_backward_naive(dout, cache):
    x, w, b, conv_param, x_pad = cache
    stride, pad = conv_param['stride'], conv_param['pad']
    N, C, H, W = x.shape
    F, _, HH, WW = w.shape
    _, _, H_out, W_out = dout.shape

    dx_pad = np.zeros_like(x_pad)
    dw = np.zeros_like(w)
    db = np.zeros_like(b)

    db = np.sum(dout, axis=(0,2,3))

    for i in range(H_out):
        for j in range(W_out):
            x_slice = x_pad[:, :, i*stride:i*stride+HH, j*stride:j*stride+WW]
            for f in range(F):
                dw[f] += np.sum(x_slice * (dout[:, f, i, j])[:,None,None,None], axis=0)
            for n in range(N):
                dx_pad[n,:,i*stride:i*stride+HH,j*stride:j*stride+WW] += np.sum(
                    (w[:,:,:,:] * (dout[n,:,i,j])[:,None,None,None]), axis=0)

    dx = dx_pad[:,:,pad:pad+H,pad:pad+W]
    return dx, dw, db


def max_pool_forward_naive(x, pool_param):
    N, C, H, W = x.shape
    ph, pw, stride = pool_param['pool_height'], pool_param['pool_width'], pool_param['stride']
    H_out = 1 + (H - ph) // stride
    W_out = 1 + (W - pw) // stride
    out = np.zeros((N, C, H_out, W_out))

    for i in range(H_out):
        for j in range(W_out):
            x_slice = x[:,:,i*stride:i*stride+ph,j*stride:j*stride+pw]
            out[:,:,i,j] = np.max(x_slice, axis=(2,3))

    cache = (x, pool_param)
    return out, cache


def max_pool_backward_naive(dout, cache):
    x, pool_param = cache
    N, C, H, W = x.shape
    ph, pw, stride = pool_param['pool_height'], pool_param['pool_width'], pool_param['stride']
    H_out = 1 + (H - ph) // stride
    W_out = 1 + (W - pw) // stride
    dx = np.zeros_like(x)

    for i in range(H_out):
        for j in range(W_out):
            x_slice = x[:,:,i*stride:i*stride+ph,j*stride:j*stride+pw]
            max_vals = np.max(x_slice, axis=(2,3), keepdims=True)
            mask = (x_slice == max_vals)
            dx[:,:,i*stride:i*stride+ph,j*stride:j*stride+pw] += mask * (dout[:,:,i,j])[:,:,None,None]
    return dx


def spatial_batchnorm_forward(x, gamma, beta, bn_param):
    N, C, H, W = x.shape
    x_flat = x.transpose(0,2,3,1).reshape(-1, C)
    out_flat, cache = batchnorm_forward(x_flat, gamma, beta, bn_param)
    out = out_flat.reshape(N, H, W, C).transpose(0,3,1,2)
    return out, cache


def spatial_batchnorm_backward(dout, cache):
    N, C, H, W = dout.shape
    dout_flat = dout.transpose(0,2,3,1).reshape(-1, C)
    dx_flat, dgamma, dbeta = batchnorm_backward(dout_flat, cache)
    dx = dx_flat.reshape(N, H, W, C).transpose(0,3,1,2)
    return dx, dgamma, dbeta


def spatial_groupnorm_forward(x, gamma, beta, G, gn_param):
    N, C, H, W = x.shape
    eps = gn_param.get('eps', 1e-5)
    x_group = x.reshape(N, G, C//G, H, W)
    mean = np.mean(x_group, axis=(2,3,4), keepdims=True)
    var = np.var(x_group, axis=(2,3,4), keepdims=True)
    std = np.sqrt(var + eps)
    x_norm = (x_group - mean) / std
    x_norm = x_norm.reshape(N, C, H, W)
    out = gamma * x_norm + beta
    cache = (G, x, x_norm, mean, var, std, gamma, beta, eps)
    return out, cache


def spatial_groupnorm_backward(dout, cache):
    G, x, x_norm, mean, var, std, gamma, beta, eps = cache
    N, C, H, W = x.shape
    # gradients of gamma and beta
    dbeta = np.sum(dout, axis=(0,2,3), keepdims=True)
    dgamma = np.sum(dout * x_norm, axis=(0,2,3), keepdims=True)
    dx_norm = dout * gamma

    x_group = x.reshape(N, G, C//G, H, W)
    dx_norm_group = dx_norm.reshape(N, G, C//G, H, W)
    m = C//G * H * W

    dvar = np.sum(dx_norm_group * (x_group-mean) * -0.5 * (var+eps)**(-1.5), axis=(2,3,4), keepdims=True)
    dmean = np.sum(dx_norm_group * -1/std, axis=(2,3,4), keepdims=True) + dvar * np.mean(-2*(x_group-mean), axis=(2,3,4), keepdims=True)

    dx_group = dx_norm_group/std + dvar*2*(x_group-mean)/m + dmean/m
    dx = dx_group.reshape(N, C, H, W)
    return dx, dgamma.reshape(gamma.shape), dbeta.reshape(beta.shape)
